public interface FlyweightIntr {
  public String getCompany();
  public String getAddress();
  public String getCity();
  public String getState();
  public String getZip();
}
